<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register</title>
    <link rel="stylesheet" href="assets/demo.css">
    <link rel="stylesheet" href="assets/form-validation.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
</head>
    <header>
        <h1>TA Modul 8 : Nining Parwati (6701174151)</h1>
    </header>
    <div class="main-content">
        <!-- You only need this form and the form-validation.css -->
        <form class="form-validation" method="post">
            <div class="form-title-row">
                <h1>Registrasi</h1>
            </div>
            <div class="form-row">
                <label>
                    <span>Username</span>
                    <input type="text" name="username">
                </label>
            </div>
            <div class="form-row">
                <label>
                    <span>Password</span>
                    <input type="password" name="password">
                </label>
            </div>
            <div class="form-row">
                <label>
                    <span>Konfirmasi Password</span>
                    <input type="password" name="repassword">
                </label>
            </div>
            <div class="form-row form-input-email-row">
                <label>
                    <span>Email</span>
                    <input type="email" name="email" value="email@example.com">
                </label>
                <span class="form-valid-data-sign"><i class="fa fa-check"></i></span>
                <span class="form-invalid-data-sign"><i class="fa fa-close"></i></span>
                <span class="form-invalid-data-info"></span>
            </div>
            <div class="form-row">
                <button type="submit" name="regis">Registrasi</button>
            </div>
        </form>
    </div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        // Here is how to show an error message next to a form field
        var errorField = $('.form-input-name-row');
        // Adding the form-invalid-data class will show
        // the error message and the red x for that field
        errorField.addClass('form-invalid-data');
        errorField.find('.form-invalid-data-info').text('Please enter your name');
        // Here is how to mark a field with a green check mark
        var successField = $('.form-input-email-row');
        successField.addClass('form-valid-data');
    });
</script>
</body>
</html>

<?php 
include "koneksi.php";
if (isset($_POST['regis'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    if (empty($username)) {
        echo "Username belum diisi";
    }
    if (empty($password)) {
        echo "Password belum diisi";
    }
    if (empty($email)) {
        echo "Email belum diisi";
    }
    
    if (strlen($username)>20){
        echo "Username maksimal 20 karakter";
        header("Location:register.php");
    }
    if (strlen($password)<6) {
        echo "Password minimal 6 karakter";
    }
    
    $query = mysqli_query($conn, "INSERT INTO user(id,username,password,email) VALUES('','$username','$password','$email')");

    if ($query) {
        echo "Data berhasil diunggah";
        header("Location:index.php");
    }else{
        echo "Data gagal diunggah".mysqli_error($query);
    }
}
 ?>