<?php 
include "koneksi.php";
mysql_query("DELETE FROM data WHERE nim='$nim'")or die(mysql_error());
 
header("location:profil.php");
 ?>