 <body bgcolor="#adebeb">
 	<div align="center">
		<?php 
			if (isset($_POST['edit'])) {
				session_start();
				echo "Akun : ".$_SESSION['username']."<br><br>";
				$conn=mysqli_connect('localhost','root','','d_tamodul6');
				/*
				if (!$conn) {
					echo "gagal DB";
				}else{
					echo "konek";
				}
				*/

				$nama 		= $_POST['nama'];
				$nim  		= $_POST['nim'];
				$kelas 		= $_POST['kelas'];
				$jk 		= $_POST['hobi'];
				$hobi 		= $_POST['film'];
				$fakultas 	= $_POST['wisata'];
				$alamat 	= $_POST['tanggal'];
				

				$sql=("UPDATE t_tamodul6 SET nama='$nama', nim='$nim', kelas='$kelas', hobi='$hobi', film='$film', wisata='$wisata', tgl='$tanggal' WHERE nim='$nim' ");
					
				if (mysqli_query($conn, $sql)) {
					echo "Update data berhasil disimpan. <br>";
				}else{
					echo "Update gagal disimpan :".mysqli_error($conn);
				}

			}
			echo "Apakah Anda ingin kembali ke halaman awal? <br>";
		 ?>


		 <form method="POST">
		 	<input type="submit" name="kembali" value="HALAMAN AWAL">
		 </form>

		  <?php 
		 if (isset($_POST['kembali'])) {
		  	header("Location:profile.php");
		  	  } ?>
</div>
 </body>