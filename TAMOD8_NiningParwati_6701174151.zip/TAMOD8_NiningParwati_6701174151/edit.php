<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Edit</title>

    <link rel="stylesheet" href="assets/demo.css">
    <link rel="stylesheet" href="assets/form-basic.css">

</head>


    <header>
        <h1>TA Modul 8 : Nining Parwati (6701174151)</h1>
        
    </header>


    <div class="main-content">

        <!-- You only need this form and the form-basic.css -->

        <form class="form-basic" method="POST">

            <div class="form-title-row">
                <h1>Edit Profil</h1>
            </div>

            <div class="form-row">
                <label>
                    <span>Nama Lengkap</span>
                    <input type="text" name="nama">
                </label>
            </div>
            <div class="form-row">
                <label>
                    <span>NIM</span>
                    <input type="text" name="nim">
                </label>
            </div>
            <div class="form-row">
                <label>
                    <span>Kelas</span>
                    <input type="text" name="kelas">
                </label>
            </div>
            <div class="form-row">
                <label>
                    <span>Hobi</span>
                    <input type="text" name="hobi">
                </label>
            </div>
            <div class="form-row">
                <label>
                    <span>Genre Film</span> &nbsp
                    <input type="checkbox" name="film" value="Horor"> &nbsp Horor
                    <input type="checkbox" name="film" value="Anime"> &nbsp Anime
                    <input type="checkbox" name="film" value="Action"> &nbsp Action
                    <input type="checkbox" name="film" value="Drama"> &nbsp Drama
                </label>
            </div>
            <div class="form-row">
                <label>
                    <span>Tempat Wisata</span> &nbsp
                     <input type="checkbox" name="wisata" value="Bali"> &nbsp Bali
                     <input type="checkbox" name="wisata" value="Tanjung Selor"> &nbsp Tanjung Selor
                     <input type="checkbox" name="wisata" value="Jakarta"> &nbsp Jakarta
                     <input type="checkbox" name="wisata" value="Lombok"> &nbspLombok
                </label>
            </div>
            <div class="form-row">
                <label>
                    <span>Tanggal Lahir</span>
                    <input type="date" name="tanggal">
                </label>
            </div>
            <div class="form-row">
                <button type="submit" name="simpan">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</body>
</html>

<?php 
session_start();
include "koneksi.php";
if (isset($_POST['simpan'])) {
    $nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $kelas = $_POST['kelas'];
    $hobi = $_POST['hobi'];
    $film = $_POST['film'];
    $wisata = $_POST['wisata'];
    $tanggal = $_POST['tanggal'];

    $_SESSION['nama']=$_POST['nama'];
    $_SESSION['nim']=$_POST['nim'];
    $_SESSION['kelas']=$_POST['kelas'];
    $_SESSION['hobi']=$_POST['hobi'];
    $_SESSION['film']=$_POST['film'];
    $_SESSION['wisata']=$_POST['wisata'];
    $_SESSION['tanggal']=$_POST['tanggal'];

  /*  $insert = mysqli_query($conn, "INSERT INTO data(nama,nim,kelas,hobi,film,wisata,tgl) VALUES('$nama','$nim','$kelas','$hobi','$film','$wisata','$tanggal')");
    if ($insert) {
        echo "Berhasil input data";
        header("Location:update.php");
    }
    else{
        echo "Gagal input data".mysqli_error($insert);
    }
    */
}
 ?>