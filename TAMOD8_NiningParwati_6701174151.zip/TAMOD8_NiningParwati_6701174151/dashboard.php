<head>
		<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
		<link rel="stylesheet" href="css/datatables/datatables.css">

</head>
<body>

		<div id="wrap">
			<div class="container">
            <h3>Data Semua User</h3>
				<table cellpadding="0" cellspacing="0" border="0" class="datatable table table-striped table-bordered">

<?php 
include "koneksi.php";
$result = mysqli_query($conn, "SELECT * FROM data");

echo 
'<table border="1px">
	<thead>
		<tr>
			<th> Nama Lengkap </th>
			<th> NIM </th>
			<th> Kelas </th>
			<th> Hobi </th>
			<th> Genre Film </th>
			<th> Tempat Wisata </th>
			<th> Tanggal Lahir </th>
			
		</tr>
	</thead>
	<tbody>';

$row = mysqli_fetch_array($result);
	echo 
	'<tr>
		<td>'.$row['nama'].'</td>
		<td>'.$row['nim'].'</td>
		<td>'.$row['kelas'].'</td>
		<td>'.$row['hobi'].'</td>
		<td>'.$row['film'].'</td>
		<td>'.$row['wisata'].'</td>
		<td>'.$row['tgl'].'</td>
	</tr>';

		echo '

	</tbody>
</table>';
 ?>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
		<script src="//cdnjs.cloudflare.com/ajax/libs/datatables/1.9.4/jquery.dataTables.min.js"></script>
		<script src="js/datatables/datatables.js"></script>
		<script type="text/javascript">
		$(document).ready(function() {
			$('.datatable').dataTable({
				"sPaginationType": "bs_four_button"
			});	
			$('.datatable').each(function(){
				var datatable = $(this);
				// SEARCH - Add the placeholder for Search and Turn this into in-line form control
				var search_input = datatable.closest('.dataTables_wrapper').find('div[id$=_filter] input');
				search_input.attr('placeholder', 'Search');
				search_input.addClass('form-control input-sm');
				// LENGTH - Inline-Form control
				var length_sel = datatable.closest('.dataTables_wrapper').find('div[id$=_length] select');
				length_sel.addClass('form-control input-sm');
			});
		});
		</script>
