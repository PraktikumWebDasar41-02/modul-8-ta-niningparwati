

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Index</title>
	<link rel="stylesheet" href="assets/demo.css">
	<link rel="stylesheet" href="assets/form-login.css">
</head>
	<header>
		<h1>TA Modul 8 : Nining Parwati (6701174151)</h1>
    </header>
    <div class="main-content">
        <!-- You only need this form and the form-login.css -->
        <form class="form-login" method="POST">
            <div class="form-log-in-with-email">
                <div class="form-white-background">
                    <div class="form-title-row">
                        <h1>Log in</h1>
                    </div>
                    <div class="form-row">
                        <label>
                            <span>Username</span>
                            <input type="text" name="username">
                        </label>
                    </div>
                    <div class="form-row">
                        <label>
                            <span>Password</span>
                            <input type="password" name="password">
                        </label>
                    </div>
                    <div class="form-row">
                        <button type="submit" name="login">Log in</button>
                    </div>
                </div>
                belum punya akun? <br> <br>
                <a href="register.php" class="form-create-an-account">Buat Akun &rarr;</a>
            </div>
        </form>
    </div>
</body>
</html>

<?php 
session_start();
include "koneksi.php";
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $_SESSION['username'] = $_POST['username'];

    $query = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM user WHERE username='$username' and password='$password'"));

    if ($query>0) {
        echo "Data sudah tersedia ";
        header("Location:profil.php");
    }

    else{
        echo "Username atau Password salah atau belum terdaftar. Pastikan Anda sudah mempunyai akun.".mysqli_error($query);
        header("Location:index.php");
    }
}
 ?>